/* eslint-disable */
var serviceEndpoint = {
    port: '4567',
    platform: 'fetch'
};
/* eslint-enable */
