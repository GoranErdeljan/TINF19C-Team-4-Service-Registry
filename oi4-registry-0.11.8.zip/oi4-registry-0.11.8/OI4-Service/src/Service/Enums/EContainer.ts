export enum EAssetType {
    device = 'device',
    application = 'application,'
}