
set -x

echo "removing UI from host fs"
rm -r /usr/local/share/cockpit/OI4-Registry
echo "...done removing UI from cockpit host fs"