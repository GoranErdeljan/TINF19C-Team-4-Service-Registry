/* eslint-disable */
var serviceEndpoint = {
    address: 'localhost',
    port: '4567',
    platform: 'cockpit'
};
/* eslint-enable */
