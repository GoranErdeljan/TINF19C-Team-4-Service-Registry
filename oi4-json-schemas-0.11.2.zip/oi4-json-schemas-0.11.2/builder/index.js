const rootDir = '.';
const fs = require('fs');
let tempJson;
let tempPath;
// Get lookup for serviceTypes, resources and methods
tempPath = `${rootDir}/schemas/serviceType.schema.json`
tempJson = readJSON(tempPath);
const serviceTypeArr = tempJson.enum;
// console.log(serviceTypeArr);

let serviceTypeRegEx = createRegExFromArr(serviceTypeArr);
console.log(serviceTypeRegEx);

tempPath = `${rootDir}/schemas/resources.schema.json`
tempJson = readJSON(tempPath);
const resourceArr = tempJson.enum;
// console.log(resourceArr);

let resourceRegEx = createRegExFromArr(resourceArr);
console.log(resourceRegEx);

tempPath = `${rootDir}/schemas/method.schema.json`
tempJson = readJSON(tempPath);
const methodArr = tempJson.enum;
// console.log(methodArr);

let methodRegEx = createRegExFromArr(methodArr);
console.log(methodRegEx);

tempPath = `${rootDir}/schemas/oi4Identifier.schema.json`
tempJson = readJSON(tempPath);

const oi4IdRegEx = tempJson.pattern.slice(1).slice(0,-1).replace('/','\\/').replace('^/','^\\/');
console.log(oi4IdRegEx);


// Build RegEx for NetworkMessage
const publisherIdRegEx = `^${serviceTypeRegEx}\\/${oi4IdRegEx}$`
console.log(`PublisherIdRegEx: ${publisherIdRegEx}`);
// Build RegEx for subscriptionList
const topicPathRegEx = `^oi4\\/${serviceTypeRegEx.replace(')','|\\+|#)')}\\/${oi4IdRegEx.replace('[a-zA-Z0-9]))','[a-zA-Z0-9])|\\+|#)')}\\/${methodRegEx.replace(')','|\\+|#)')}\\/${resourceRegEx.replace(')','|\\+|#)')}(.*)$`
console.log(`TopicPathRegEx: ${topicPathRegEx}`);

// Read Modify Write NetworkSchemaJson
tempPath = `${rootDir}/schemas/NetworkMessage.schema.json`
tempJson = readJSON(tempPath);
tempJson.properties.PublisherId.pattern = publisherIdRegEx;
tempJson.properties.MessageId.pattern = `^.{1,}-${publisherIdRegEx.slice(1)}`;
writeJSON(tempPath, tempJson);

// Read Modify Write subscriptionListJson
tempPath = `${rootDir}/schemas/subscriptionList.schema.json`
tempJson = readJSON(tempPath);
tempJson.definitions.subscriptionListObject.properties.topicPath.pattern = topicPathRegEx;
writeJSON(tempPath, tempJson);

function createRegExFromArr(arr) {
    let regex = '(';
    for (const entry of arr) {
        regex = `${regex}${entry}|`;
    }
    regex = regex.slice(0, -1);
    regex = `${regex})`
    return regex;
}

function readJSON(path) {
    const json = JSON.parse(fs.readFileSync(path));
    return json;
}

function writeJSON(path, objLiteral) {
    fs.writeFileSync(path, `${JSON.stringify(objLiteral, null, 2)}`);
}

tempJson = readJSON(tempPath);
console.log(tempJson.definitions.subscriptionListObject.properties.topicPath.pattern);